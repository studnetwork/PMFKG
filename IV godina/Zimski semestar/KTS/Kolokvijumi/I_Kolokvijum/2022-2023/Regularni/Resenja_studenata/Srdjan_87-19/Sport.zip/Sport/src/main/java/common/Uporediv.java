package common;

import izuzeci.Neuporedivo;
import osobe.Osoba;

public interface Uporediv 
{
	int uporedi(Object osoba) throws Neuporedivo;
}
