package common;

public interface MerljivUcinak
{

	int indeksKorisnosti();
}
