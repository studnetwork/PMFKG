package izuzeci;

public class SportistaNijeOdgovarajuci extends Exception 
{
	public SportistaNijeOdgovarajuci(String poruka)
	{
		super(poruka);
	}
}
