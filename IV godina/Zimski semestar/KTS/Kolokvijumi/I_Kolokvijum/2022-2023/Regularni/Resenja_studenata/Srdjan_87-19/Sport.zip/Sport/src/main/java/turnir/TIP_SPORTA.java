package turnir;

public enum TIP_SPORTA
{
	KOSARKA,
	FUDBAL
}
