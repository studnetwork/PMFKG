package izuzeci;

public class Neuporedivo extends Exception 
{

	public Neuporedivo(String poruka) {
		super(poruka);
		// TODO Auto-generated constructor stub
	}
}
