package turnir;

public enum TIP_STATISTIKE
{
	GOLOVI,
	ASISTENCIJE,
	KOSEVI
}