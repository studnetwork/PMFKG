package izuzeci;

public class NemaDovoljnoNovca extends Exception
{
	public NemaDovoljnoNovca(String poruka)
	{
		super(poruka);
	}
}
