export const environment = {
    production: false,
    backendUrl:"http://localhost", // TODO obratiti paznju ovde; ako se ne stavi sema (`http`) onda se u HttpClient metodama posmatra kao relativna putanja
    backendPort: 3000
  };