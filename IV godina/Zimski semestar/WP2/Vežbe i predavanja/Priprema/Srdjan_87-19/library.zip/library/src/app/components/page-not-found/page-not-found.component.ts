import { Component } from '@angular/core';

/**
 * Kreirano sa: `ng g c components/page-not-found`
 */
@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent {

}
