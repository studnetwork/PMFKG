import { Component } from '@angular/core';

/**
 * Kreirano sa: `ng g c components/authors`
 */
@Component({
  selector: 'app-authors',
  templateUrl: './authors.component.html',
  styleUrls: ['./authors.component.css']
})
export class AuthorsComponent {

}
