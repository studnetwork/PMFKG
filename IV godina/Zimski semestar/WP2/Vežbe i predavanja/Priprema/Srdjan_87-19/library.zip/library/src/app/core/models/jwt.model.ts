/**
 * Kreirano sa: `ng g interface core/models/jwt --type=model`
 */
export interface Jwt {
    token: string
}