Public Class.
{
public static void main( String args[] ){}
}
