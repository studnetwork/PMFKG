#include <stdio.h>
#include <stdlib.h>

struct lista{
	float broj;
	struct lista *pret,*sled;
};

void dodaj(struct lista **p,struct lista **q,float vred){
	struct lista *temp;	
	temp=(struct lista *)malloc(sizeof(struct lista));
	temp->broj=vred;
	temp->sled=NULL;
	if (*p==NULL) {
		*p=*q=temp;
		temp->pret=NULL;
	}
	else{
		(*q)->sled=temp;
		temp->pret=*q;
		*q=temp;
	}
}
		
int formlist(struct lista **p,struct lista **q){	
	int n,i;
	float vred;
	*p=*q=NULL;
	printf("Unesi broj elemenata:\n");
	scanf("%d",&n);
	printf("Unesi elemente:\n");
	for (i=0;i<n;i++){
		scanf("%f",&vred);
		dodaj(p,q,vred);
	}
	return(n);
}

float prosek(struct lista *p,int n){
	float as=0.0;
	int i;
	for(i=0;i<n;i++){
		as+=p->broj;
		p=p->sled;
	}
	as/=n;
	return(as);
}

void podlista(struct lista *p,int *indeks,int *duzina,float as){
	int i;
	*indeks=*duzina=0;	
	i=1;
	while((p!=NULL) && (p->broj<=as)) {
		p=p->sled;
		i++;
	}
	if (p!=NULL){
		*indeks=i;
		*duzina=1;
		p=p->sled;
		while ((p!=NULL) && (p->broj>as)){
			(*duzina)++;
			p=p->sled;
		}
	}
}

void ispisliste(struct lista *q,int n,int indeks,int duzina){
	int i;
	printf("Ispis liste od kraja:\n");
	if (indeks==0) while(q!=NULL){
		printf("%f ",q->broj);
		q=q->pret;
	}
	else{
		for(i=0;i<n-(indeks+duzina-1);i++){
			printf("%f ",q->broj);
			q=q->pret;
		}
		for(i=0;i<duzina;i++) q=q->pret;
		for(i=0;i<indeks-1;i++){
			printf("%f ",q->broj);
			q=q->pret;
		}
	}
	printf("\n");
}

void ispispodliste(struct lista *p,int indeks,int duzina){
	int i;
	printf("Ispis podliste od pocetka:\n");
	for(i=1;i<indeks;i++) p=p->sled;
	for(i=0;i<duzina;i++){
		printf("%f ",p->broj);
		p=p->sled;
	}
	printf("\n");
}

main(){
struct lista *p,*q;
int n,indeks,duzina;
float as;
n=formlist(&p,&q);
as=prosek(p,n);
podlista(p,&indeks,&duzina,as);
ispisliste(q,n,indeks,duzina);
ispispodliste(p,indeks,duzina);
}









