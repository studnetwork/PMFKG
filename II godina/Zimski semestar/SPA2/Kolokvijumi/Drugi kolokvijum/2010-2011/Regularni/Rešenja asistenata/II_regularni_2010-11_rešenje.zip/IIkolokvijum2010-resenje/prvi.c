#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct lista
{
	char *podatak;
	struct lista *sled;
};

typedef struct lista LISTA;

LISTA* alociraj()
{
	LISTA *pom=(LISTA *)malloc(sizeof(LISTA));
	return pom;
	
}

char* alocirajstring(int v)
{
	char *pom=(char *)malloc(sizeof(char)*v);
	return pom;
}

void stampaj(LISTA *p)
{
	LISTA *pom1=p;
	do
	{
		printf("%s\t",p->podatak);
		p=p->sled;
		
	}while(p!=pom1);
	
}


LISTA* dodaj(LISTA *p)
{
	char c[20];
	int t;
	LISTA *novi,*pom1;
	pom1=p;
	
	scanf("%s",c);
	t=strlen((c)+1);
	novi=alociraj();
	novi->podatak=alocirajstring(t);
	strcpy(novi->podatak,c);
	
	if (p==NULL)
	 {
		 p=novi;
		 p->sled=p;
	 }
	 else
	 {
	 while(pom1->sled!=p) pom1=pom1->sled;
	 pom1->sled=novi;
	 novi->sled=p;
	 
	
	
     }
     return p;
	
}

void ispisio(LISTA *p,int n)
{
	LISTA  *max;
	
	LISTA *pom1,*pom2;
	while(n)
	{
		pom2=NULL;
		max=p;
		pom1=p;
		do
		   {
			   if(strcmp(max->podatak,pom1->podatak)<0) max=pom1; 
			   pom1=pom1->sled;
			}while(pom1!=p);
			printf("%s\t",max->podatak);
			max->podatak="!";
		
			
			n=n-1;
		}
			
		
		
		
		
		
	}

	
	
	
	




int main()
{  int i,n;

LISTA *p=NULL;
    printf("unesi n: ");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	p=dodaj(p);
	printf("\n");
	stampaj(p);
	printf("\n");
	printf("\n");
	printf("lista u nerastucem poretku: \n");
	printf("\n");
	ispisio(p,n);
	
	
	
	return(99);
}




