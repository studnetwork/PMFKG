#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct stablo{
	char *rec;
	struct stablo *levi,*desni;
};

void dodaj(struct stablo **p,char *s){
	struct stablo *pom1,*pom2,*temp;
	temp=(struct stablo *)malloc(sizeof(struct stablo));
	temp->rec=(char *)malloc(strlen(s)+1);
	strcpy(temp->rec,s);
	temp->levi=temp->desni=NULL;
	if (*p==NULL) *p=temp;
	else{
		pom1=*p;
		while (pom1!=NULL){
			pom2=pom1;
			if (strcmp(s,pom1->rec)<0) pom1=pom1->levi;
			else pom1=pom1->desni;
		}
		if (strcmp(s,pom2->rec)<0) pom2->levi=temp;
		else pom2->desni=temp;
	}
}

struct stablo *formtree(){
	struct stablo *p;
	int n,i;
	char s[50];
	p=NULL;
	printf("Unesi broj elemenata:\n");
	scanf("%d",&n);
	printf("Unesi elemente:\n");
	for (i=0;i<n;i++){
		scanf("%s",&s);
		dodaj(&p,s);
	}
	return(p);
}

void ispis(struct stablo *p){
	if (p!=NULL){
		printf("%s\n",p->rec);
		ispis(p->levi);
		ispis(p->desni);
	}
}

int broj(struct stablo *p){
	int s;
	if (p==NULL) return(0);
	if ((p->levi==NULL) || (p->desni==NULL)) return(0);
	s=broj(p->levi)+broj(p->desni);
	if (strlen(p->levi->rec)>strlen(p->desni->rec)) s++;
	return(s);
}

main(){
struct stablo *p;
p=formtree();
printf("Broj trazenih cvorova je %d.\n",broj(p));
printf("Ispis stabla:\n");
ispis(p);
printf("\n");
}














	
	
			
