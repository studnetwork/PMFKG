#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct m{
	char *n, *p;
	float t,h;
	int ch;
	struct m *next;
	}Station;

Station *addData(Station *head, Station *n){
	Station *t = head;
	
	if (!head){
		head = n;
		}
	else{
		n->next = head;
		head = n;
		}
	return head;
	}

Station *formStationList(Station *head, FILE **f){
	Station *n;
	int t = 1;
	FILE *tf = *f;
	char s[100];
	
	while(t){
		n = (Station *)malloc(sizeof(Station));
		fgets(s, 100, tf);
		if (strcmp(s,"KRAJ\n") != 0){
			n->n = (char *)malloc(strlen(s) + 1);
			strcpy(n->n,s);
			fgets(s,100, tf);
			n->p = (char *)malloc(strlen(s) + 1);
			strcpy(n->p, s);
			fscanf(tf,"%f%f", &n->t, &n->h);
			fgetc(tf);
			head = addData(head, n);
			}
		else t = 0;
		}
	return head;
	}

void printStationList(Station *head){
	if (!head){
		printf("Lista je prazna!\n");
		exit(0);
		}
	else
		while (head){
			printf("%s%s%f\n%f\n\n", head->n, head->p, head->t, head->h);
			head = head->next;
			}
	}
void deleteFrom(Station *p, Station *t, char *N, char *P){
	
	p = t;
	t = t->next;
	
	while (t){
		if ((strcmp(t->n, N) == 0) && (strcmp(t->p, P) == 0)){
			p->next = t->next;
			free(t);
			t = t->next;
			}
		else {
			p = t;
			t = t->next;
			}
		}
	}

void update(Station *head, char *N, char *P, int k){
	Station *t = head, *p = NULL;
	int n = 0;
	while (t){
		if ((strcmp(t->n, N) == 0) && (strcmp(t->p, P) == 0)){
			n++;
			t->ch = 1;
			if (n == k){ 
				deleteFrom(p, t, N, P);
				return;
				}
			}
		p = t;
		t = t->next;
		}

	}



void updateStationList(Station *head, int k){
	Station *t = head;
	int n = 0;
	
	while (t){
		if (t->ch == 0){
			update(t, t->n, t->p, k);
			}
		t = t->next;
		}
	
	}
	
int count(Station *head){
	int n = 0; 
	if (!head) return 0;
	else 
		while (head){
			n++;
			head = head->next;
			}
	return n;
	}

void printReverse(Station *head, int n){
	Station *t = head;
	int  i = 0;
	if (n){
	if (!head){
		printf("Lista je prazna!");
		exit(0);
		}
	else{
		while (i < n-1){
			t = t->next;
			i++;
			}
		printf("%s%s%f\n%f\n\n", t->n, t->p, t->t, t->h);
		printReverse(head, n-1);
		}
	}
	}	

float avgTemp(Station *head){
	Station *temp = head;
	float sum = 0.0;
	int n = 0;
	
	while(temp){
		n++;
		sum = sum + temp->t;
		temp = temp->next;
		}
	if (n)
		return(sum/n);
	else
		return 0;
	}

int main(int argc, char *argv[]){
	Station *Slist =NULL;
	FILE *f;
	int k;
	
	f = fopen(argv[1], "r");
	if (!f){
		printf("Greska sa fajlom!\n");
		exit(0);
		}
	Slist = formStationList(Slist, &f);
	printStationList(Slist);
	fscanf(f,"%d", &k);
	updateStationList(Slist, k);
	printf("Azurirana lista:\n");
	printReverse(Slist, count(Slist));
	printf("Prosecna temperatura je: %f\n", avgTemp(Slist));
	}
