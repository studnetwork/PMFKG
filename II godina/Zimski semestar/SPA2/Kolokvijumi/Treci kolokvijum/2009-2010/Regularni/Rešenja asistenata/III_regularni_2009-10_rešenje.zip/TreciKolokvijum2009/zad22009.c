#include <stdio.h>
#include <stdlib.h>

enum{CRVENA, CRNA};

struct Cvor
{
	int broj;
	int boja;
	struct Cvor *roditelj;
	struct Cvor *levi;
	struct Cvor *desni;
};

void drotacija(struct Cvor **q)
{
	struct Cvor *poml, *pomd;
	pomd = *q;
	poml = pomd -> levi;
	pomd -> levi = poml -> desni;
	if(poml -> desni)
		poml -> desni -> roditelj = pomd;
	poml -> roditelj = pomd -> roditelj;
	if(pomd -> roditelj)
	{
		if(pomd -> roditelj -> levi == poml)
			pomd -> roditelj -> levi = poml;
		else
			pomd -> roditelj -> desni = poml;
	}
	poml -> desni = pomd;
	pomd -> roditelj = poml;
	*q = poml;
}

void lrotacija(struct Cvor **q)
{
	struct Cvor *poml, *pomd;
	poml = *q;
	pomd = poml -> desni;
	poml -> desni = pomd -> levi;
	if(pomd -> levi)
		pomd -> levi -> roditelj = poml;
	pomd -> roditelj = poml -> roditelj;
	if(poml -> roditelj)
	{
		if(poml == poml -> roditelj -> levi)
			poml -> roditelj -> levi = pomd;
		else
			poml -> roditelj -> desni = pomd;
	}	
	pomd -> levi = poml;
	poml -> roditelj = pomd;
	*q = pomd;
}

void popravi(struct Cvor **p, struct Cvor *temp)
{
	struct Cvor *ujka, *deda;
	while(temp -> roditelj && temp -> roditelj -> boja == CRVENA)
	{
		if(temp -> roditelj == temp -> roditelj -> roditelj -> levi)
		{
			ujka = temp -> roditelj -> roditelj -> desni;
			if(ujka && ujka -> boja == CRVENA)
			{
				temp -> roditelj -> boja = CRNA;
				ujka -> boja = CRNA;
				temp -> roditelj -> roditelj -> boja = CRVENA;
				temp =  temp -> roditelj -> roditelj;
			}
			else
			{
				if(temp == temp -> roditelj -> desni)
				{
					temp = temp -> roditelj;
					lrotacija(&temp);
					if(temp -> roditelj == NULL) *p = temp;
					temp = temp -> levi;					
				}
				deda = temp -> roditelj -> roditelj;
				deda -> boja = CRVENA;
				temp -> roditelj -> boja = CRNA;
				drotacija(&deda);
				if(deda -> roditelj == NULL) *p = deda;
			}	
		}
		else
		{
			ujka = temp -> roditelj -> roditelj -> levi;
			if(ujka && ujka -> boja == CRVENA)
			{
				temp -> roditelj -> boja = CRNA;
				ujka -> boja = CRNA;
				temp -> roditelj -> roditelj -> boja = CRVENA;
				temp =  temp -> roditelj -> roditelj;
			}
			else
			{
				if(temp == temp -> roditelj -> levi)
				{
					temp = temp -> roditelj;
					drotacija(&temp);
					if(temp -> roditelj == NULL) *p = temp;
					temp = temp -> desni;					
				}
				deda = temp -> roditelj -> roditelj;
				deda -> boja = CRVENA;
				temp -> roditelj -> boja = CRNA;
				lrotacija(&deda);
				if(deda -> roditelj == NULL) *p = deda;
			}
		}
	}
	(*p) -> boja = CRNA;
}

void dodaj(struct Cvor **p, struct Cvor *temp)
{
	struct Cvor *pom1, *pom2;
	pom1 = *p;
	pom2 = NULL;
	while(pom1)
	{
		pom2 = pom1;
		if(temp -> broj < pom1 -> broj)
			pom1 = pom1 -> levi;
		else
			pom1 = pom1 -> desni;
	}
	if(pom2 == NULL)
	{ 
		*p = temp;
		(*p) -> roditelj = NULL;
	}
	else
	{
		if(temp -> broj < pom2 -> broj)
		{
			pom2 -> levi = temp;
			pom2 -> levi -> roditelj = pom2;
		}
		else
		{
			pom2 -> desni = temp;
			pom2 -> desni -> roditelj = pom2;
		}
	}
	popravi(p, temp);
}

void Unos(struct Cvor **root)
{
	struct Cvor *temp;
	struct Cvor *p = *root;
	int n,i;
	printf("Unesite n: ");
	scanf("%d",&n);
	for(i = 0; i < n; i++)
	{
		temp = (struct Cvor *)malloc(sizeof(struct Cvor));
		temp -> levi = temp -> desni = NULL;
		temp -> boja = CRVENA;
		scanf("%d",&(temp -> broj));
		dodaj(&p, temp);
	}
	*root = p;
}

void Ispis(struct Cvor *root)
{
	if(root)
	{
		Ispis(root -> levi);
		if(root -> boja == 0)
			printf("%d <%s>\n",root -> broj, "CRVENA");
		else
			printf("%d <%s>\n",root -> broj, "CRNA");
		Ispis(root -> desni);
	}
}

void Brisi(struct Cvor *root,struct Cvor **root1,int m)
{
	struct Cvor *temp;
	if(root)
	{
		if(((root -> broj) % 10) != m)

		{
			temp = (struct Cvor *)malloc(sizeof(struct Cvor));
			temp -> levi = temp -> desni = NULL;
			temp -> boja = CRVENA;
			temp -> broj = root -> broj;
			dodaj(root1, temp);
			Brisi(root -> levi, root1, m);
			Brisi(root -> desni, root1, m);
		}
		else	
		{
			Brisi(root -> levi, root1, m);
			Brisi(root -> desni, root1, m);
		}
	}
	else return;
}

float Srednja(struct Cvor *root)
{
	struct Cvor *poml, *pomd;
	int brojac = 0;
	float vrednost = 0;
	if(root)
	{
		poml = root -> levi;
		pomd = root -> desni;
		if(poml)
		{
			if(poml -> levi)
			{
				brojac++;
				vrednost += poml -> levi -> broj;
			}
			if(poml -> desni)
			{
				brojac++;
				vrednost += poml -> desni -> broj;
			}
		}
		if(pomd)
		{
			if(pomd -> levi)
			{
				brojac++;
				vrednost += pomd -> levi -> broj;
			}
			if(pomd -> desni)
			{
				brojac++;
				vrednost += pomd -> desni -> broj;
			}
		}
		if(brojac != 0 && vrednost != 0) return (vrednost/brojac);
		else return 0;
	}
	else return 0;
}
main()
{
	struct Cvor *root = NULL;
	struct Cvor *root1 = NULL;
	int m;
	float n;	
	Unos(&root);
	Ispis(root);
	n = Srednja(root);
	printf("Srednja vrednost je: %.2f\n",n);
	printf("Unesite broj koji zelite da obrisete: ");
	scanf("%d",&m);
	Brisi(root, &root1, m);
	root = root1;
	Ispis(root);

}
