#include <stdio.h>
#include <stdlib.h>

struct cvor
{
	int broj;
	int balans;
	struct cvor *levi, *desni;
};

int dubina(struct cvor *p)
{
	int dd=0, dl=0;

	if(p)
	{

		if(p->levi) dl=dubina(p->levi);
		if(p->desni) dd=dubina(p->desni);
	
		if(dl>dd) return ++dl;
		else  return ++dd;

	}else return 0;
}

void lrotacija(struct cvor **p)
{
	struct cvor *poml, *pomd;

	poml = *p;
	pomd = poml->desni;
	poml->desni = pomd->levi;
	pomd->levi = poml;
	*p = pomd;

	poml->balans = dubina(poml->desni) - dubina(poml->levi);
	pomd->balans = dubina(pomd->desni) - dubina(pomd->levi);
}

void drotacija(struct cvor **p)
{
	struct cvor *poml, *pomd;

	pomd = *p;
	poml = pomd->levi;
	pomd->levi = poml->desni;
	poml->desni = pomd;
	*p = poml;


	poml->balans = dubina(poml->desni) - dubina(poml->levi);
	pomd->balans = dubina(pomd->desni) - dubina(pomd->levi);
}

void sredi(struct cvor **p)
{
	struct cvor *t=*p;

	if(t->balans < - 1)
	{
		if(t->levi->balans<0) drotacija(&t);
		else
		{
			lrotacija(&(t->levi));
			drotacija(&t);
		}
	}
	else if(t->balans>1)
	{
		if(t->desni->balans>0) lrotacija(&t);
		else
		{
			drotacija(&(t->desni));
			lrotacija(&t);
		}
	}
	
	*p=t;
	
}
int nadji(struct cvor **p)
{
	int rezultat;
	struct cvor *t=*p;
	
	if(!t->levi)
	{
		rezultat = t->broj;
		t=t->desni;
		

	}else rezultat = nadji(&(t->levi));

	if(t)
	{
		t->balans = dubina(t->desni) - dubina(t->levi);
		sredi(&t);
	}

	*p = t;
	return (rezultat);
}


struct cvor* obrisi(struct cvor *p, int k)
{
	struct cvor *t;	

	if(p==NULL) return NULL;

	if(p->broj==k)
	{
		if(!p->levi && !p->desni)
		{
			free(p);
			return NULL;
		}
		if(!p->levi && p->desni)
		{
			t=p->desni;
			free(p);
			return t;
		}
		if(p->levi && !p->desni)
		{
			t=p->levi;
			free(p);
			return t;
		}		
		if(p->levi && p->desni)
		{
			p->broj = nadji(&(p->desni));

			p->balans = dubina(p->desni) - dubina(p->levi);
			sredi(&p);
			return p;
		}
	}

	if(k>p->broj)
	{
		p->desni = obrisi(p->desni,k);
		p->balans = dubina(p->desni) - dubina(p->levi);
		sredi(&p);
		return p;
	}
	else
	{
		p->levi = obrisi(p->levi,k);
		p->balans = dubina(p->desni) - dubina(p->levi);
		sredi(&p);
		return p;	
	}
}

int dodaj(struct cvor **p, int k)
{
	int inkrement, rezultat=0;
	struct cvor *t=*p;


	if(t==NULL)
	{
		t = (struct cvor*)malloc(sizeof(struct cvor));

		t->broj = k;
		t->balans = 0;
		t->levi=t->desni = NULL;
		rezultat = 1;
	}
	else
	{
		if(k>t->broj) inkrement = dodaj(&(t->desni),k);
		else inkrement = -dodaj(&(t->levi),k);

		t->balans += inkrement;

		if(inkrement!=0 && t->balans!=0)
		{
			if(t->balans < -1)
			{
				if(t->levi->balans < 0) drotacija(&t);
				else
				{
					lrotacija(&(t->levi));
					drotacija(&t);
				}
			}else if(t->balans>1)
				{
						
					if(t->desni->balans>0) lrotacija(&t);
					else 
					{
						drotacija(&(t->desni));
						lrotacija(&t);
					}					
				

				}else rezultat = 1;
		}
	}
	
	*p=t;

	return rezultat;
}

void stampaj(struct cvor *p)
{
	if(p)
	{
		stampaj(p->desni);
		printf("%d <%d>\n",p->broj,p->balans);
		stampaj(p->levi);
	}
}
float srednjaVrednost(struct cvor *p, int k)
{
	int brojac = 0;
	float s;
	
	if(p==NULL) return -1;

	if((p)->broj == k) return 0;

	s=p->broj;
	brojac++;
	if(k<p->broj)
		p=p->levi;
	else
		p=p->desni;

	while(p!=NULL)
	{
		if(p->broj==k) return (s/brojac);
		else 
		{
			s+=p->broj;
			brojac++;
			
			if(k<p->broj)
				p=p->levi;
			else
				p=p->desni;
		} 
	}

	return 0;
	
}

main()
{
	struct cvor *koren = NULL;
	int i, n, pom1;
	float pom;
 	
	printf("Unesite broj elemenata stabla: ");
	scanf("%d",&n);	
	
	printf("Unesite elemente stabla\n");
	for(i=1; i<=n; i++)
	{
		scanf("%d",&pom1);		
		dodaj(&koren,pom1);
	}
	
	
	printf("\nUneti elementi su: \n");
	stampaj(koren);

	printf("\nUnesite broj za pretragu: ");
	scanf("%d",&pom1);
	printf("suma je = %f\n",srednjaVrednost(koren, pom1));
	
	printf("\nUnesite broj za brisanje: ",&pom1);
	scanf("%d",&pom1);
	koren = obrisi(koren, pom1);

	printf("\nLista posle brisanja: \n");
	stampaj(koren);
    system("pause");	
	

}































