/*_______________________________________________________________               
  |                  Djordje Krecar 66/09                        |
  |__________________- AVL STABLA ( 3 )_-________________________| */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct cvor
{
	int podatak;
	int balans;
	struct cvor *levi,*desni;
};

typedef struct cvor CVOR;

CVOR* alociraj()
{
	CVOR *pom=(CVOR *)malloc(sizeof(CVOR));
	return pom;
	
}

int dubina(CVOR *p)
{
	int dd=0,dl=0;
	
	if(p)
	{
	   if(p->levi) dl=dubina(p->levi);
	   if(p->desni) dd=dubina(p->desni);
	   if (dd>dl)	return dd++;
	   else return dl++;
	}
	else return 0;
	
}

float srednja(CVOR *p)
{
	int z=0,b=0;
	float s=0.0;
	
	if((p->levi==NULL)&&(p->desni==NULL)) return (-1.0);
	if ((p->levi->levi== NULL) &&  
		 (p->levi->desni== NULL) &&
		 (p->desni->levi == NULL) &&
		 (p->desni->desni == NULL)  )  
		   
			   
			   return (-1.0);
		   
	    if ((p->levi->levi!=NULL) && (p->levi->levi->podatak % 2 != 0)) {z=z+p->levi->levi->podatak; b++;}
		if ((p->levi->desni!=NULL) && (p->levi->desni->podatak % 2 != 0)) {z=z+p->levi->desni->podatak; b++;}
		if ((p->desni->levi!=NULL) && (p->desni->levi->podatak % 2 != 0)) {z=z+p->desni->levi->podatak; b++;}
		if ((p->desni->desni!=NULL) && (p->desni->desni->podatak % 2 != 0))  { z=z+p->desni->desni->podatak; b++;}
		
		if(z==0) return (-2.0);
		s=z/b;
	    return s;
}	

void lrotacija(CVOR **p)
{
	CVOR *poml,*pomd;
	poml=(*p);
	pomd=poml->desni;
	poml->desni=pomd->levi;
	pomd->levi=poml;
	(*p)=pomd;
	
	poml->balans=dubina(poml->desni)-dubina(poml->levi);
	pomd->balans=dubina(pomd->desni)-dubina(pomd->levi);
	
}

void drotacija(CVOR **p)
{
	CVOR *poml,*pomd;
	pomd=(*p);
	poml=pomd->levi;
	pomd->levi=poml->desni;
	poml->desni=pomd;
	(*p)=poml;
	
	poml->balans=dubina(poml->desni)-dubina(poml->levi);
	pomd->balans=dubina(pomd->desni)-dubina(pomd->levi);
	
}

void unos(CVOR **p)
{
	CVOR *temp,*pom;
	pom=(*p);
	int n,i,k;
	printf("unesi n: \t");
	scanf("%d",&n);
	if(n<1) {printf("n mora preko 0\n"); exit(0); }
	else
	for(i=0;i<n;i++)
      {
		  printf("unesi %d. cvor: \t",i+1);
		  scanf("%d",&k);
		  temp=alociraj();
		  temp->levi=temp->desni=NULL;
		  temp->podatak=k;
		  dodaj(&pom,temp);
		  
       }
	(*p)=pom;
}
	
int dodaj(CVOR **p,CVOR *temp)	
{
	int rez=0,inkrement;
	CVOR *pom=(*p);
	
	if(pom==NULL)
	  {
		  pom=temp;
		  pom->balans=0;
		  rez=1;
	  }
	  else
	    {
			if(pom->podatak > temp->podatak) inkrement=-dodaj(&(pom->levi),temp);
			else inkrement=dodaj(&(pom->desni),temp);
			
			pom->balans=pom->balans+inkrement;
			
			if((pom->balans!=0) && (inkrement!=0))
			   { 
				   if(pom->balans < -1)
				     {
						 if(pom->levi->balans <0 ) drotacija(&pom);
						 else { lrotacija(&(pom->levi)); drotacija(&pom);  } }
						 
				   else if (pom->balans > 1)
				        {
							if(pom->desni->balans >0 ) lrotacija(&pom);
						 else { drotacija(&(pom->desni)); lrotacija(&pom);  } }
			else rez=1;
		   }
		   
	   }
	   (*p)=pom;
		   return rez;
   }			 
							
	  
void ispis(CVOR *p)
{
	if(p)
	{
		if (p->levi) ispis(p->levi);
		printf("cvor: %d\t balans  <%d>",p->podatak,p->balans);
		printf("\n");
		
		if(p->desni) ispis(p->desni);
		
	}
	
}	

void brisi(CVOR *p,CVOR **q,int w)
{
	CVOR *temp;
	
	if(p)
	{
		if((p->podatak %10)!=w)
		  {
			  temp=alociraj();
			  temp->levi=temp->desni=NULL;
			  temp->podatak=p->podatak;
			  dodaj(q,temp);
			  
			  brisi(p->levi,q,w);
			  brisi(p->desni,q,w);
		  }
	  
		  else
	  {
		  brisi(p->levi,q,w);
	      brisi(p->desni,q,w);
	  }
  }
	  else return;
	
}	




int main()
{    
	int w;
	float s;
	CVOR *p=NULL,*q=NULL;
	unos(&p);
	printf("stablo pre brisanja: \n");
	ispis(p);
	
	s=srednja(p);
	printf("\n ");
	if (p==NULL) {printf("prazno stablo\n"); exit(0);}
	if((s!=(-1.0)) && (s!=(-2.0)))
	{
	printf("Srednja vrednost neparnih brojeva na 3. nivou: ");
	printf("%.2f\n",s);
}
else if(s==(-1.0)) printf("NEMA 3. NIVOA\n"); 
else if(s==(-2.0)) printf("NEMA NEPARNIH BROJEVA NA 3. NIVOU\n"); 

	
	
	
	printf("Sta se brise: ");
	scanf("%d",&w);
	brisi(p,&q,w);
	printf("stablo posle brisanja: \n");
	
	p=q;
	if(p==NULL) printf("nema elemenata");
	else
	ispis(p);
	
	
	
system("Pause");
}






