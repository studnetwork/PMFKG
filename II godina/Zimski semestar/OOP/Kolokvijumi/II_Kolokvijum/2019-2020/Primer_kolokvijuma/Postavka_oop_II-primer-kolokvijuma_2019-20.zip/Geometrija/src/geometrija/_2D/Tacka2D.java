package geometrija._2D;


// Konkretan tip Tacka2D koji je Tacka
public class Tacka2D  
{
	// Privatne realne promenljive x i y koje predstavljaju 2D coordinate tacke
	double X, Y;

	// Javni konstruktor koji setuje x i y koordinatu tacke
	Tacka2D(double X, double Y) 
	{

	}
	
	// Implementiran metod rastojanje iz klase Tacka koji racuna rastojanje od tacke koja je prosledjena kao ulazni parameter
	double rastojanje(Tacka tacka) 
	{
		return 0.0;
		
	}
	
	// Javni metod rastojanje koji ima realnu povratnu vrednost. 
	// Metod ima dva ulazna realna parametra x i y koji predstavljaju koordinate 
	// tacke u 2D prostoru od koje se racuna rastojanje
	public double rastojanje(double x, double y)
	{	
		return 0.0;
	}
	
	// Javne pristupne metode za sve promenljive
	double getX() {
		
	}

	double getY() {
		
	}

}
