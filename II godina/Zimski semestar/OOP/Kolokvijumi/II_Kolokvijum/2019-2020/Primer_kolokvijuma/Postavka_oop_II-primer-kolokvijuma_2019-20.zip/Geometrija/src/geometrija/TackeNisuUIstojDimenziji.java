package geometrija;

// Konkretan tip TackeNisuUIstojDimenziji koji predstavlja gre�ku 
public class TackeNisuUIstojDimenziji
{

	// Privatne promenljive t1 i t2 tipa Tacka
	Tacka t1, t2;
	
	// Javni konstruktor koji ima dva ulazna parametra tipa Tacka kojima se setuju vrednosti t1 i t2
	public TackeNisuUIstojDimenziji(Tacka t1, Tacka t2)
	{

	}
	
	// Prepisanu metodu toString koja vraca poruku da tacke t1 i t2 nisu u istoj dimenziji
	@Override
	public String toString() 
	{
		return null;
	}
}
