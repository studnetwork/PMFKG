package geometrija;


// Apstraktan tip Tacka 
public class Tacka 
{
	
	//Javnu promenljivu id koja predstavlja jedinstveni broj tacke
	int id;
	
	
	//Javni podrazumevani konstruktor u kome se setuje vrednost id promenljive
	public Tacka()
	{

	}
	
	/*
	 * Javnu apstraktnu metodu rastojanje koja ima realnu povratnu vrednost. 
	 * Metoda ima jedan ulazni parameter tipa Tacka. Metoda definise mogucnost 
	 * bacanja izuzetka tipa TackeNisuUIstojDimenziji.
	 */
	double rastojanje(Tacka tacka)
}
