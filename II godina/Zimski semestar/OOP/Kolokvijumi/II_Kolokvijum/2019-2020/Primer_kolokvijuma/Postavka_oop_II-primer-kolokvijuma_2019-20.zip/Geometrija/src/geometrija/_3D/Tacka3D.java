package geometrija._3D;

// Konkretan tip Tacka3D koji je Tacka2D
class Tacka3D 
{

	// Privatnu realnu promenljivu z koja predstavlja trecu koordinatu tacke
	double z;
	
	// Javni konstruktor koji setuje x, y i z koordinatu tacke.
	Tacka3D(double X, double Y, double Z) {

	}

	// Prepisan metod rastojanje iz klase Tacka2D koji racuna rastojanje od tacke koja je prosledjena kao ulazni parameter. 
	// Ukoliko prosledjena tacka nije iz trodimenzionalnog prostora baciti izuzetak TackeNisuUIstojDimenziji
	double rastojanje(Tacka tacka)
	{
		
	}
	
	// Javni metod rastojanje koji ima realnu povratnu vrednost. Metod ima tri ulazna realna parametra x, y i z koji 
	// predstavljaju koordinate tacke u 3D prostoru od koje se racuna rastojanje.
	double rastojanje(double x, double y, double z)
	{	

	}

	// Pristupnu metodu promenljivoj z.
	double getZ()
	{

	}
	
	//Prepisan metod toString koja vraca sve tri koordinate tacke.
	public String toString() {

	}
}
