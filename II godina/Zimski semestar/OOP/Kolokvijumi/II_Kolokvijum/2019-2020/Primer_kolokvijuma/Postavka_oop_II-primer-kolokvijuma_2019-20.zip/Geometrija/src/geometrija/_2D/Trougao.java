package geometrija._2D;

// Konkretan tip Trougao je GeometrijskaFigura
class Trougao {

	//Promenljive a, b, c koje su tipa Tacka i imaju vidljivost samo u paketu
	Tacka a, b, c;
	
	// Javni konstruktor koji setuje sve tri tacke
	Trougao(Tacka a, Tacka b, Tacka c) 
	{

	}

	// Implementiran metod dajObim koja racuna obim trougla
	double dajObim() {
		
		return 0.0;
	}


	// Implementiran metod dajPovrsinu koja racuna povrsinu trougla
	double dajPovrsinu() {
		
		return 0.0;
	}

	//Javne pristupne metode za sve promenljive
	Tacka getA() {
		
	}

	Tacka getB() {
		
	}

	Tacka getC() {
		
	}
	
	// Prepisan metod toString koja vraca string reprezentaciju svih tacaka trougla
	String toString() {
		
	}

}
