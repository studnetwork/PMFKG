package geometrija._2D;

//Apstraktan tip GeometrijskaFigura koja je GeometrijskiOblik
public class GeometrijskaFigura 
{
	// Javnu apstraktnu metodu dajObim koja vraca realnu vrednost
	double dajObim()
	
}
