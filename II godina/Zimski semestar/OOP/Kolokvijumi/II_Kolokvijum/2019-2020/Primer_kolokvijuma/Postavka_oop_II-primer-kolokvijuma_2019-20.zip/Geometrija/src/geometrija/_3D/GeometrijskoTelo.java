package geometrija._3D;

// Apstraktan tip GeometrijskoTelo
class GeometrijskoTelo  
{
	// Javnu apstraktnu metodu dajZapreminu koja vraca realnu vrednost
	double dajZapreminu()
}
