package geometrija._3D;

// Konkretan tip Lopta koji je GeometrijskoTelo
public class Lopta 
{

	// Promenljivu tipa Tacka3D koja se vidi samo u klasi i predstavlja centar lopte
	Tacka3D centar;
	// Realnu promenljivu r koja predstavlja poluprecnik lopte
	double r;
	
	// Javni konstruktor koji setuje obe promenljive
	Lopta(Tacka3D centar, double r)
	{

	}
	
	// Implementiran metod dajZapreminu koja racuna zapreminu lopte
	double dajZapreminu() 
	{
		
	}

	// Implementiran metod dajZapreminu koja racuna zapreminu lopte
	double dajPovrsinu() 
	{
		return 0.0;
	}

}
