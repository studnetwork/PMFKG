package geometrija;

// Apstraktan tip GeometrijskiOblik
public class GeometrijskiOblik 
{
	// Javnu apstraktnu metodu dajPovrsinu koja vraca realnu vrednost
	double dajPovrsinu()
}
