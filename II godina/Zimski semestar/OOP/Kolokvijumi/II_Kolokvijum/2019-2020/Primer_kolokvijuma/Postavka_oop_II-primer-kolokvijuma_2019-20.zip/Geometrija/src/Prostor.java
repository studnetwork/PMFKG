// Konkretan tip Prostor
public class Prostor
{
	// Promenljivu koja predstavlja niz geometrijskih oblika
	GeometrijskiOblik[] geometrijskiOblici;
	
	// Javni konstruktor kome se prosledjuje kapacitet niza geometrijskih oblika
	Prostor(int kapacitet)
	{
		
	}
	
	// Javni metod dodajGeometrijskiOblik koji prihvata jednu promenljivu tipa GeometrijskiOblik i skladisti je u niz
	void dodajGeometrijskiOblik(GeometrijskiOblik go)
	{
		
	}
	
	// Javni metod dajZapreminuSvihOblikaKojiJeImaju koja vraca ukupnu zapreminu svih geometrijskih oblika koji imaju zapreminu
	double dajZapreminuSvihOblikaKojiJeImaju()
	{
		return 0.0;
	}
	
	// Javni metod dajPovrsinuSvihOblika koja vraca ukupnu povrsinu svih geometrijskih oblika
	GeometrijskiOblik[] dajBazeSvihOblikaKojiJeImaju()
	{
		return null;
	}
	
	// Javni metod dajBazeSvihOblikaKojiJeImaju koji vraca niz baza svih oblika koji ih imaju
	double dajPovrsinuSvihOblika()
	{
		
		return 0.0;
	}
	
	// Sortiraj tela prema zapremini, a figure prema obimu - bonus (2 poena)
	public void sortirajgeometrijskeOblike()
	{
		
	}
}
