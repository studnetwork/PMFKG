package geometrija._3D;

// Apstraktan tip ITeloSaBazom
interface ITeloSaBazom 
{
	// Javnu apstraktnu metodu dajPovrsinuBaze koja vraca realnu vrednost
	
	// Javnu apstraktnu metodu dajObimBaze koja vraca realnu vrednost
	
	// Javnu apstraktnu metodu dajBazu koja vraca GeometrijskiOblik
	
}
