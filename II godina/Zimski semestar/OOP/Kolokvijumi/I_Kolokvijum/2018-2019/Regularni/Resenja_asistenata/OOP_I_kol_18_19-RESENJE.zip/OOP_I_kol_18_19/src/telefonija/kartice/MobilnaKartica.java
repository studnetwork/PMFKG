package telefonija.kartice;

public abstract class MobilnaKartica {
	protected String brojKartice;
	private int potroseniMinuti = 0;
	private int brojPoslatihSMS = 0;
	
	public MobilnaKartica(String brojKartice) {
		this.brojKartice = brojKartice;
	}
	
	public String getBrojKartice() {
		return brojKartice;
	}
	
	public int getPotroseniMinuti() {
		return potroseniMinuti;
	}

	public void dodajPotroseneMinute(int potroseniMinuti) {
		this.potroseniMinuti += potroseniMinuti;
	}

	public void dodajPoslateSMSove(int brojPoslatihSMS) {
		this.brojPoslatihSMS += brojPoslatihSMS;
	}

	public double dajRacun()
	{
		return potroseniMinuti * Cenovnik.getCenaMinutaMobilneTelefonije() +
				+ brojPoslatihSMS * Cenovnik.getCenaSMS();
	}
}
