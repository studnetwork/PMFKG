import telefonija.FiksniTelefon;
import telefonija.MobilniTelefon;
import telefonija.Telefon;
import telefonija.kartice.IPopust;
import telefonija.kartice.MTSKartica;
import telefonija.kartice.VIPKartica;

public class Test {

	public static void main(String[] args) {

		Telefon telefoni[] = new Telefon[3];

		FiksniTelefon ft1 = new FiksniTelefon("Samsung", "034235874");
		ft1.razgovor(120);
		telefoni[0] = ft1;

		MobilniTelefon mt = new MobilniTelefon("Huawei", 2);
		telefoni[1] = mt;

		MTSKartica mtsKartica1 = new MTSKartica("064111111", 10);
		VIPKartica vipKartica = new VIPKartica("060222222");
		MTSKartica mtsKartica2 = new MTSKartica("065123456", 10);

		try {
			mt.dodajKarticu(mtsKartica1);
			mt.dodajKarticu(vipKartica);
			mt.dodajKarticu(mtsKartica2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		try {
			mt.razgovor("064111111", 12);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		try {
			mt.razgovor("060222222", 15);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		try {
			mt.posaljiSMSove("060222222", 4);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		FiksniTelefon ft2 = new FiksniTelefon("LG", "034235874");
		ft2.razgovor(100);
		telefoni[2] = ft2;

		ispisiUkupniRacun(telefoni);
		spisakPotrosnje(telefoni);
		ispisiUkupniPopust(telefoni);

		try {
			System.out.println("Potrosnja izbacene kartice: " + mt.izbaciKarticu("060222222")); 
			ispisiUkupniRacun(telefoni);
			spisakPotrosnje(telefoni);
			ispisiUkupniPopust(telefoni);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	private static void ispisiUkupniPopust(Telefon[] telefoni) {
		
		double popust = 0.0;
		for (Telefon telefon : telefoni) {
			if(telefon instanceof IPopust)
			{
				popust += ((IPopust)telefon).dajPopust();
			}
		}
		System.out.println("Ukupni popust: " + popust);

	}

	private static void spisakPotrosnje(Telefon[] telefoni) {

		for (Telefon telefon : telefoni) {
			System.out.println(telefon);
		}
	}

	private static void ispisiUkupniRacun(Telefon[] telefoni) {
		// Ukupni racun
		double racun = 0.0;
		for (Telefon telefon : telefoni) {
			if(telefon != null)
				racun += telefon.dajRacun();
		}
		System.out.println("Ukupni racun: " + racun);
	}

}
