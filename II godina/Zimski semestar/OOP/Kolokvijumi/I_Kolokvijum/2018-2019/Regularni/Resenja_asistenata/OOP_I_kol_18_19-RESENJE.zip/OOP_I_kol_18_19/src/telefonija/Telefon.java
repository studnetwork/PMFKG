package telefonija;

public abstract class Telefon {
	private String proizvodjac;
	
	public Telefon(String proizvodjac) {
		this.proizvodjac = proizvodjac;
	}
	
	public String getProizvodjac() {
		return proizvodjac;
	}

	public abstract double dajRacun();
	
	@Override
	public String toString() {
		if (this instanceof FiksniTelefon)
			return "Fiksni: " + ((FiksniTelefon)this).getBrojTelefona() + "\nRacun: " + dajRacun();
		else if (this instanceof MobilniTelefon) 
			return "Mobilni: " + ((MobilniTelefon)this).dajBrojeveKartica() + "\nRacun: " + dajRacun();
		else
			return "Nepoznata vrsta uredjaja!";
	}
}
