package telefonija;

import telefonija.kartice.Cenovnik;

public class FiksniTelefon extends Telefon {

	private int potroseniMinuti = 0;
	private String brojTelefona;
	
	public FiksniTelefon(String proizvodjac, String brojTelefona) {
		super(proizvodjac);
		this.brojTelefona = brojTelefona;
	}

	@Override
	public double dajRacun() {
		return potroseniMinuti * Cenovnik.getCenaMinutaFiksneTelefonije();
	}

	public String getBrojTelefona() {
		return brojTelefona;
	}
	
	public void razgovor(int minuti) {
		potroseniMinuti += minuti;
	}
}
