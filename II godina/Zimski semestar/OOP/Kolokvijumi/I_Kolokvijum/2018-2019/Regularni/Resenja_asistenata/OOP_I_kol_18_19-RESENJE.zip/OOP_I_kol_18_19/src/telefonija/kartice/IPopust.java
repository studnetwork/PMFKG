package telefonija.kartice;

public interface IPopust {
	double dajPopust();
}
