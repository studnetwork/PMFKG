package telefonija;

import telefonija.kartice.IPopust;
import telefonija.kartice.MobilnaKartica;

public class MobilniTelefon extends Telefon implements IPopust {

	private MobilnaKartica kartice[];

	public MobilniTelefon(String proizvodjac, int brojKartica) {
		super(proizvodjac);
		kartice = new MobilnaKartica[brojKartica];
	}

	@Override
	public double dajRacun() {
		double racun = 0.0;

		for (int i = 0; i < kartice.length; i++) {
			if (kartice[i] != null)
				racun += kartice[i].dajRacun();
		}

		return racun;
	}

	public String dajBrojeveKartica() {
		String brojevi = "";

		for (int i = 0; i < kartice.length; i++) {
			if (kartice[i] != null)
				brojevi += "[" + kartice[i].getBrojKartice() + "]";
		}

		return brojevi;
	}

	public double dajPopust() {
		double popust = 0.0;

		for (int i = 0; i < kartice.length; i++) {
			if (kartice[i] != null && kartice[i] instanceof IPopust)
				popust += ((IPopust) kartice[i]).dajPopust();
		}

		return popust;
	}

	public void dodajKarticu(MobilnaKartica kartica) throws Exception {

		for (int i = 0; i < kartice.length; i++) {
			if (kartice[i] == null) {
				kartice[i] = kartica;
				return;
			}
		}

		throw new Exception("Svi slotovi za kartice su popunjeni!");
	}

	public double izbaciKarticu(String brojKartice) throws Exception {
		double racun = 0.0;

		for (int i = 0; i < kartice.length; i++) {

			if (kartice[i] != null && kartice[i].getBrojKartice().equals(brojKartice)) {
				racun = kartice[i].dajRacun();
				kartice[i] = null;
				return racun;
			}
		}

		throw new Exception("Kartica ne postoji!");
	}

	public void razgovor(String brojKartice, int potroseniMinuti) {
		for (MobilnaKartica mobilnaKartica : kartice) {
			if (mobilnaKartica != null && mobilnaKartica.getBrojKartice().equals(brojKartice)) {
				mobilnaKartica.dodajPotroseneMinute(potroseniMinuti);
			}
		}

	}
	
	public void posaljiSMSove(String brojKartice, int brojSMSova) {
		for (MobilnaKartica mobilnaKartica : kartice) {
			if (mobilnaKartica != null && mobilnaKartica.getBrojKartice().equals(brojKartice)) {
				mobilnaKartica.dodajPoslateSMSove(brojSMSova);
			}
		}

	}
}
