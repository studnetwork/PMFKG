package telefonija.kartice;

public class MTSKartica extends MobilnaKartica {

	int besplatniMinuti;
	
	public MTSKartica(String brojKartice, int besplatniMinuti) {
		super(brojKartice);
		this.besplatniMinuti = besplatniMinuti;
	}
	
	@Override
	public double dajRacun() {
		if(getPotroseniMinuti() > besplatniMinuti)
			return super.dajRacun() - besplatniMinuti * Cenovnik.getCenaMinutaMobilneTelefonije();
		else
			return super.dajRacun() - getPotroseniMinuti() * Cenovnik.getCenaMinutaMobilneTelefonije();
	}
}
