package merljivi;

public interface Merljiv {
	
	double dajUkupnuTezinu();
	String dajID();
}
