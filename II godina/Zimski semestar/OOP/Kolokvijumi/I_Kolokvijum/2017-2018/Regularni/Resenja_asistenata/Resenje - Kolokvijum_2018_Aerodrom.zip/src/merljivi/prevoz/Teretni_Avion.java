package merljivi.prevoz;

import merljivi.Merljiv;
import merljivi.tovar.Kontejner;


public class Teretni_Avion extends Avion{

	
	public Teretni_Avion(String naziv, double maksimalnaTezina, double tezinaPrazan) throws Exception {
		super(naziv, maksimalnaTezina, tezinaPrazan);		
	}

	public void dodajMerljiv(Merljiv merljiv) throws Exception {
		if(merljiv instanceof Kontejner) {
			for (int i = 0; i < nizMerljivih.length; i++) {
				if(nizMerljivih[i] == null) {
					nizMerljivih[i] = merljiv;
					return;
				}
			}
		}
		else {
			throw new Exception("Merljiv tip nije kontejner.");
		}

	}

	public void dodajMerljiv(Merljiv merljiv, int pozicija) throws Exception {
		if(nizMerljivih[pozicija] != null)
			throw new Exception("Zauzeta pozicija.");
		nizMerljivih[pozicija] = merljiv;
	}

}
