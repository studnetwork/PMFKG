package merljivi.tovar;

import merljivi.Merljiv;

public class Paket implements Merljiv {
	
	protected String opis;
	private double tezina;
	
	public Paket(String opis, double tezina) {
		super();
		this.opis = opis;
		this.tezina = tezina;
	}

	public double dajUkupnuTezinu() {		
		return tezina;
	}

	public String dajID() {
		return opis;
	}

}
