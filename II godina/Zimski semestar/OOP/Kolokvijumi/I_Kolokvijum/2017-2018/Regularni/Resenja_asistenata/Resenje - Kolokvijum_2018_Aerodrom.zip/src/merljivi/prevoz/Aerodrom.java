package merljivi.prevoz;

import merljivi.Merljiv;
import merljivi.Osoba;

public class Aerodrom {

	String oznaka;
	private Avion nizAviona[];

	public Aerodrom(String oznaka, int kapacitet) {
		super();
		this.oznaka = oznaka;
		nizAviona = new Avion[kapacitet];
	}

	public void avionSlece(Avion avion) {
		for (int i = 0; i < nizAviona.length; i++) {
			if (nizAviona[i] == null) {
				nizAviona[i] = avion;
				break;
			}
		}
	}

	public void avionPolece(String oznaka) {
		for (int i = 0; i < nizAviona.length; i++) {
			if (nizAviona[i] != null && oznaka.toString().equals(nizAviona[i].dajID())) {
				System.out.println(nizAviona[i]);
				nizAviona[i] = null;
				break;
			}
		}
	}

	public void dodajMerljiv(String oznaka, Merljiv merljiv) {
		for (int i = 0; i < nizAviona.length; i++) {
			if (nizAviona[i] != null && oznaka.toString().equals(nizAviona[i].dajID())) {
				try {
					nizAviona[i].dodajMerljiv(merljiv);
					break;
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
			}
		}
	}

	public Osoba[] dajSpisakOsoba() {

		Osoba niz[] = new Osoba[100];
		int k = 0;

		for (int i = 0; i < nizAviona.length; i++) {
			Avion avion = nizAviona[i];
			if (avion != null) {
				if (avion instanceof Putnicki_Avion) {
					for (int j = 0; j < avion.nizMerljivih.length; j++) {
						Merljiv merljiv = avion.nizMerljivih[j];
						if (merljiv instanceof Osoba) {
							niz[k++] = (Osoba) merljiv;
						}
					}
				}
			}
		}
		return niz;
	}

	public double dajTezinuSvih() {
		double rezultat = 0;

		for (int i = 0; i < nizAviona.length; i++) {
			Avion avion = nizAviona[i];
			if (avion != null) {
				rezultat += avion.dajUkupnuTezinu();
			}
		}
		return rezultat;
	}

	public String toString() {

		String s = "";

		for (Avion avion : nizAviona) {

			if (avion != null) {

				String oznaka = "";
				if (avion instanceof Putnicki_Avion) {
					s += ("P " + avion.naziv + " " + avion.dajUkupnuTezinu() + "\n" + avion + "\n");
					;
				} else if (avion instanceof Teretni_Avion) {
					s += ("T " + avion.naziv + " " + avion.dajUkupnuTezinu() + "\n");

					for (int i = 0; i < avion.nizMerljivih.length; i++) {
						if (avion.nizMerljivih[i] != null)
							s += avion.nizMerljivih[i] + "\n";
					}
				}

			}
		}

		return s;
	}

}
