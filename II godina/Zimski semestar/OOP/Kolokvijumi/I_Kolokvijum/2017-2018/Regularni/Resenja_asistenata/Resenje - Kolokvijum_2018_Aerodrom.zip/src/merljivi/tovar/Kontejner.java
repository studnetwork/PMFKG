package merljivi.tovar;

import merljivi.Merljiv;
import merljivi.Osoba;

public class Kontejner implements Merljiv {
	
	static int GeneratorID = 0;
	private int id;
	private double tezinaPrazan;
	Merljiv nizMerljivih[];
	
	
	public Kontejner(double tezinaPrazan, int kapacitet) {
		super();
		this.id = GeneratorID;
		GeneratorID += 1;
		this.tezinaPrazan = tezinaPrazan;
		nizMerljivih = new Merljiv[kapacitet];		
	}

	public double dajUkupnuTezinu() {
		double rezultat = tezinaPrazan;

		for (int i = 0; i < nizMerljivih.length; i++) {
			Merljiv merljiv = nizMerljivih[i];
			if(merljiv != null) {
				rezultat += merljiv.dajUkupnuTezinu();
			}			
		}		
		return rezultat;
	}
	
	public void dodatiMerljivTip(Merljiv merljiv) throws Exception{
		if(merljiv instanceof Osoba)
			throw new Exception("Osoba se ne sme dodati u kontejner!");
		
		for (int i = 0; i < nizMerljivih.length; i++) {
			if(nizMerljivih[i] == null) {
				nizMerljivih[i] = merljiv;
				return;
			}
		}		
		throw new Exception("Nema mesta za novi merljiv.");
	}
	
	public Merljiv dajMerljivTip(String id) {
		for (int i = 0; i < nizMerljivih.length; i++) {
			Merljiv merljiv = nizMerljivih[i];
			if(merljiv != null && merljiv.dajID().equals(id)) {
				nizMerljivih[i] = null;
				return merljiv;
			}
		}
		return null;
	}

	public String dajID() {
		return id + "";
	}

}
















