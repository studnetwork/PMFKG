package merljivi.prevoz;

import merljivi.Merljiv;

public abstract class Avion implements Merljiv {

	String naziv;
	double maksimalnaTezina = 1000;
	private double tezinaPrazan;
	Merljiv nizMerljivih[] = new Merljiv[10];
	
	public Avion(String naziv, double maksimalnaTezina, double tezinaPrazan) throws Exception {
		super();
		if(naziv.length() != 10)
			throw new Exception("Naziv nema 10 karaktera.");
		this.naziv = naziv;
		this.maksimalnaTezina = maksimalnaTezina;
		this.tezinaPrazan = tezinaPrazan;
	}
	public abstract void dodajMerljiv(Merljiv merljiv) throws Exception;
	public abstract void dodajMerljiv(Merljiv merljiv, int pozicija) throws Exception;
	
	public Merljiv dajMerljiv(int pozicija) throws Exception{
		if(nizMerljivih[pozicija] != null)
			return nizMerljivih[pozicija];		
		throw new Exception("Na datoj poziciji nema nicega.");		 
	}
	
	public double dajUkupnuTezinu() {
		double rezultat = tezinaPrazan;
		
		for (int i = 0; i < nizMerljivih.length; i++) {
			Merljiv merljiv = nizMerljivih[i];
			if(merljiv != null) 
				rezultat += merljiv.dajUkupnuTezinu();
		}		
		return rezultat;
	}
	
	public String dajID() {
		return new String(naziv);
	}

	public String toString() {
		return naziv + "(" + dajUkupnuTezinu() + ")";
	}
	
}
