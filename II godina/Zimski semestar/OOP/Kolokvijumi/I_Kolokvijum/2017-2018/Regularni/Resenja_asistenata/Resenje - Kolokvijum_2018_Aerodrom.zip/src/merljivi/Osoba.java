package merljivi;

public class Osoba implements Merljiv {
	
	protected String ime;
	protected double tezina;
	
	public Osoba(String ime, double tezina) {
		super();
		this.ime = ime;
		this.tezina = tezina;
	}

	public double dajUkupnuTezinu() {
		return tezina;
	}

	public String dajID() {
		return ime;
	}
	
	public String toString() {		
		return ime+ "(" + tezina + ")";
	}

}
