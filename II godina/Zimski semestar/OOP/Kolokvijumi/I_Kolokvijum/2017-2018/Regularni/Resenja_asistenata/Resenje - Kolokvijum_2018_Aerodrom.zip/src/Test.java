import merljivi.Osoba;
import merljivi.prevoz.Aerodrom;
import merljivi.prevoz.Putnicki_Avion;
import merljivi.prevoz.Teretni_Avion;
import merljivi.tovar.Kontejner;
import merljivi.tovar.Paket;

public class Test {

	public static void main(String[] args) {

		Aerodrom aerodrom = new Aerodrom("Nikola Tesla", 2);

		Osoba osoba1 = new Osoba("Pera Peric", 82);
		Osoba osoba2 = new Osoba("Marko Markovic", 70);

		Paket paket1 = new Paket("paket 1", 15);
		Paket paket2 = new Paket("paket 2", 20);

		Kontejner kontejner1 = new Kontejner(12, 3);

		Putnicki_Avion putnickiAvion = null;
		try {

			putnickiAvion = new Putnicki_Avion("Boing__747", 15000, 1000);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		if(putnickiAvion != null)
		{
			try {
				putnickiAvion.dodajMerljiv(osoba1);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			try {
				putnickiAvion.dodajMerljiv(osoba2);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			try {
				putnickiAvion.dodajMerljiv(paket1);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			try {
				putnickiAvion.dodajMerljiv(paket2);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			
			try {
				putnickiAvion.dodajMerljiv(kontejner1);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

			aerodrom.avionSlece(putnickiAvion);
		}

		Kontejner kontejner2 = new Kontejner(15, 3);

		try {
			kontejner2.dodatiMerljivTip(new Paket("opis1", 15));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		try {
			kontejner2.dodatiMerljivTip(new Paket("opis2", 9));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		try {
			Teretni_Avion teretniAvion = new Teretni_Avion("TER1234567", 30000, 3000);
			teretniAvion.dodajMerljiv(kontejner2);
			aerodrom.avionSlece(teretniAvion);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Kontejner kontejner3 = new Kontejner(20, 4);
		aerodrom.dodajMerljiv("TER1234567", kontejner3);

		System.out.println("********************************************");
		// Ispisati ukupnu te�inu svih aviona na aerodromu
		System.out.println("Ukupna tezina: " + aerodrom.dajTezinuSvih());

		System.out.println("********************************************");
		// Ispisati tekstualne reprezentacije svih osoba na aerodromu
		for (Osoba osoba : aerodrom.dajSpisakOsoba()) {
			if(osoba != null)
				System.out.println(osoba);
		}

		System.out.println("********************************************");
		// Ispisati tekstualnu reprezentaciju aerodroma
		System.out.println(aerodrom);
		
		System.out.println("********************************************");
		aerodrom.avionPolece("TER1234567");

		System.out.println("********************************************");
		// Ispisati tekstualnu reprezentaciju aerodroma
		System.out.println(aerodrom);

	}

}
