package merljivi.prevoz;

import merljivi.Merljiv;
import merljivi.Osoba;
import merljivi.tovar.Paket;

public class Putnicki_Avion extends Avion {

	public Putnicki_Avion(String naziv, double maksimalnaTezina, double tezinaPrazan) throws Exception {
		super(naziv, maksimalnaTezina, tezinaPrazan);
	}

	public void dodajMerljiv(Merljiv merljiv) throws Exception {
		if (merljiv instanceof Osoba || merljiv instanceof Paket) {
			for (int i = 0; i < nizMerljivih.length; i++) {
				if (nizMerljivih[i] == null) {
					nizMerljivih[i] = merljiv;
					return;
				}
			}
		} else {
			throw new Exception("Merljiv tip nije osoba/paket.");
		}

	}

	public void dodajMerljiv(Merljiv merljiv, int pozicija) throws Exception {
		if (nizMerljivih[pozicija] != null)
			throw new Exception("Zauzeta pozicija.");
		nizMerljivih[pozicija] = merljiv;
	}

	public String toString() {
		String spisak = "";
		for (int i = 0; i < nizMerljivih.length; i++) {
			if (nizMerljivih[i] != null)
				spisak += nizMerljivih[i] + "\n";
		}
		return spisak;
	}
}
